use dbOdsstage

GO

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_sistemas')
BEGIN
	Create table LGPD.Tb_sistemas(
	Id_sistemas int NOT NULL,
	Nm_sistemas varchar(100),
	Primary Key (Id_sistemas)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_sistemas_cpfs')
BEGIN
Create table LGPD.Tb_sistemas_cpfs(
	Nr_cpf varchar(20) NOT NULL,
	Nm_status Char(1) NOT NULL,
	Id_sistemas int NOT NULL,
	FOREIGN KEY (Id_sistemas) REFERENCES LGPD.Tb_sistemas(Id_sistemas)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_documento_cliente')
BEGIN
	Create table LGPD.Tb_documento_cliente(
	Id_documento_cliente int NOT NULL identity,
	Nr_cpf varchar(20),
	Primary Key (Id_documento_cliente)
	-- FOREIGN KEY (Nr_cpf) REFERENCES LGPD.Tb_cliente_detalhe(Nr_cpf)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_documento_status')
BEGIN
	Create table LGPD.Tb_documento_status(
	Id_documento_cliente int NOT NULL,
	Id_sistemas int NOT NULL,
	Nm_status Char(1),
	Nm_observacao Varchar(50),
	Dt_anonimizacao datetime,
	FOREIGN KEY (Id_documento_cliente) REFERENCES LGPD.Tb_documento_cliente(Id_documento_cliente),
	FOREIGN KEY (Id_sistemas) REFERENCES LGPD.Tb_sistemas(Id_sistemas)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_cliente_detalhe')
BEGIN
	Create table LGPD.Tb_cliente_detalhe(
	Dv_sistema  varchar(1),
	Cd_classe_produto smallint,
	Cd_vida int,
	Nr_versao_vida int,
	Cd_administradora smallint,
	Cd_filial smallint,
	Cd_produto smallint,
	Cd_proposta Varchar(10),
	Nr_cpf Varchar(20),
	Nm_participante varchar(100),
	Nm_endereco varchar(100),
	Nm_cidade varchar(100),
	Cd_uf char(4),
	Nr_cep varchar(15),
	Nr_telefone varchar(30),
	Nr_documento varchar(20),
	Nm_cei varchar(20),
	Dt_nascimento datetime,
	Nm_email varchar(Max)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_apolice_detalhe')
BEGIN
	Create table LGPD.Tb_apolice_detalhe(
	Dv_sistema varchar(1),
	Cd_classe_produto smallint,
	Id_apolice_unica int,
	Nr_versao int,
	Cd_administradora smallint,
	Cd_filial smallint,
	Cd_produto smallint,
	Cd_ramo smallint,
	Cd_convenio int,
	Cd_apolice NUMERIC(7,0),
	Cd_instituidora int,
	Nm_apolice varchar(100),
	Nr_cpf Varchar(20),
	Nm_endereco varchar(100),
	Nm_cidade varchar(100),
	Cd_uf char(4),
	Nr_cep varchar(15),
	Nr_telefone varchar(30),
	Nm_cei varchar(20),
	Nm_email varchar(Max)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_cliente_detalhe_previdencia')
BEGIN
	Create table LGPD.Tb_cliente_detalhe_previdencia(
	Cd_classe_produto smallint,
	Cd_administradora smallint,
	Cd_filial smallint,
	Cd_produto smallint,
	Cd_proposta Varchar(10),
	Nr_cpf Varchar(20),
	Nm_participante varchar(100),
	Nm_endereco varchar(100),
	Nm_cidade varchar(100),
	Cd_uf char(4),
	Nr_cep varchar(15),
	Nr_telefone varchar(30),
	Nr_documento varchar(20),
	Nm_cei varchar(20),
	Dt_nascimento datetime,
	Nm_email varchar(Max)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_apolice_detalhe_previdencia')
BEGIN
	Create table LGPD.Tb_apolice_detalhe_previdencia(
	Cd_classe_produto smallint,
	Cd_administradora smallint,
	Cd_filial smallint,
	Cd_produto smallint,
	Cd_ramo smallint,
	Cd_convenio int,
	Cd_apolice NUMERIC(7,0),
	Cd_instituidora int,
	Nm_apolice varchar(100),
	Nr_cpf Varchar(20),
	Nm_endereco varchar(100),
	Nm_cidade varchar(100),
	Cd_uf char(4),
	Nr_cep varchar(15),
	Nr_telefone varchar(30),
	Nm_cei varchar(20),
	Nm_email varchar(Max)
	)
END

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Tb_cpfs_vt')
BEGIN
	Create table LGPD.Tb_cpfs_vt(
	Nr_cpf Varchar(20) NOT NULL
	)
END

if not exists (select top 1 1 from LGPD.Tb_sistemas)
Begin
	insert into LGPD.Tb_sistemas Values(1, 'eSeg VIDA'), (2, 'eSeg Previdencia')
End

if not exists (select top 1 1 from LGPD.Tb_cpfs_vt)
Begin
	insert into LGPD.Tb_cpfs_vt Values('68841647191'),('3030780902'),('3090600951'),('54256925953'),('7243798780'),('27070439822'),('28311037892'),('14663453813'),('13619601836'),('15155511801'),('7380808885'),('78274150597'),('15270416468')
End