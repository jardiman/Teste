use dbesegprev

--exec spSeleciona_documento_cliente_Prev null
IF OBJECT_ID('spSeleciona_documento_cliente_Prev ') IS NULL
	EXEC('CREATE Procedure dbo.spSeleciona_documento_cliente_Prev  AS')
GO

/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 18/11/2021
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Seleciona todos os clientes que n�o possuem apolice ativa na Metlife n�s ultimos 10 anos
* 
**********************************************************************************/
create or alter PROCEDURE dbo.spSeleciona_documento_cliente_Prev(
	@Dt_execucao datetime 	= null
)
as

begin
	set ansi_warnings off
	set nocount on

IF 1 = 0
BEGIN
    SELECT
		CONVERT (BIGINT, 123) AS ID,
		CONVERT (varchar (500), 'Nr_cpf') AS Nr_cpf,
		CONVERT (varchar(200), 'Dt_cancelamento') AS Dt_cancelamento
END


/********************************     Cria Temps       ************************************************/

If OBJECT_ID('tempdb..#Lista_Cpfs_canc') is not null drop table #Lista_Cpfs_canc
Create table #Lista_Cpfs_canc
(
Nr_cpf Varchar(20)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_canc (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Cpfs_ativ') is not null drop table #Lista_Cpfs_ativ
Create table #Lista_Cpfs_ativ
(
Nr_cpf Varchar(20)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_ativ (Nr_cpf);

If OBJECT_ID('tempdb..#Temp_Result') is not null drop table #Temp_Result
create table #Temp_Result
(
Nr_cpf Varchar(20),
Nm_status Char(1)
)
CREATE INDEX idx_cpf ON #Temp_Result (Nr_cpf);
CREATE INDEX idx_status ON #Temp_Result (Nr_cpf, Nm_status);


/******************************************************************************************************/


declare
@Busca			datetime,
@Busca_inclusao	datetime
	
	if(@Dt_execucao is null) begin set @Dt_execucao = getdate() end
	set @Busca = dateadd(year, -10, convert(varchar(10), @Dt_execucao, 120))
	set @Busca_inclusao = dateadd(year, -10, convert(varchar(10), getdate(), 120))


/********************************  Preenche as temps canceladas  ************************************************/


	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) <= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From Proposta pro (nolock)
		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_cancelamento <= @Busca and pro.Dv_status <> 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/****************************************************************************************************************/


/********************************  Preenche as temps ativas  ************************************************/


	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where csi.Dt_implantacao >= @Busca_inclusao and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) >= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) is null and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From Proposta pro (nolock)
		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_inclusao >= @Busca_inclusao and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From Proposta pro (nolock)
		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_cancelamento >= @Busca and pro.Dv_status = 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From Proposta pro (nolock)
		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_cancelamento is null and pro.Dv_status = 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/************************************************************************************************************/

/********************************  Gerar Carga de CPFs  ************************************************/

	delete from #Lista_Cpfs_canc where Nr_cpf IN (select Nr_cpf from #Lista_Cpfs_ativ)

	-- Anonimiza
	Insert Into #Temp_Result select distinct Nr_cpf, 'S' From #Lista_Cpfs_canc
	-- N�o Anonimiza
	Insert Into #Temp_Result select distinct Nr_cpf, 'N' From #Lista_Cpfs_ativ

	select distinct Nr_cpf, Nm_status, 2 as Id_sistemas from #Temp_Result where Len(Nr_cpf) <= 12


/*******************************************************************************************************/

	set nocount off

end