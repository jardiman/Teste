Use dbmgi

-- exec spAnonimiza_exclusao_kit_cliente_eMGI 'S'
IF OBJECT_ID('spAnonimiza_exclusao_kit_cliente_eMGI ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_exclusao_kit_cliente_eMGI  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Exclui os Kits dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_exclusao_kit_cliente_eMGI(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Search Table
(
id_search bigint,
vl_key_dominio varchar(150), 
id_kit bigint
)

declare @Tipo_Kit Table
(
id_tpo_kit varchar(10)
)

declare @Kit_Cpf_Layout Table
(
id_tpo_kit varchar(10)
)

declare @Kits Table
(
id_kit bigint
)

declare @Kit_Xml Table
(
id_kit bigint,
tx_xml_recebimento Varchar(Max)
)

declare @Temp_anonimizacao_cpf Table
(
Id_anonimizacao bigint identity,
Nr_cpf Varchar(14)
)

declare @Nr_cpf Varchar(14)
declare @id_search bigint
declare @id_documento bigint
declare @Kit_Apagar bigint
declare @incr int = 1


	Insert Into @Temp_anonimizacao_cpf
	select Nr_cpf
	from Temp_anonimizacao_cpf

	Insert Into @Search
	select s.id_search, ds.vl_key_dominio as 'Cpf', id_kit
	from [dbo].[tb_det_search] ds (nolock)
		JOIN [dbo].[tb_search] s (nolock)
	On ds.id_search = s.id_search
	Where ds.ds_key_dominio = 'Nr_cpf' and vl_key_dominio <> ''

	Insert Into @Tipo_Kit
	select distinct k.id_tpo_kit
	from @Search s
		JOIN [dbo].[tb_kit] k
	On s.id_kit = k.id_kit
	Order By k.id_tpo_kit

-- N�O contem o CPF
	Insert into @Kit_Cpf_Layout
	select id_tpo_kit
	from [dbo].[tb_tpo_kit]
	Where id_tpo_kit not in (select id_tpo_kit from @Tipo_Kit)

	Insert Into @Kits
	select id_kit
	from [dbo].[tb_kit] k
		JOIN [dbo].[tb_tpo_kit] tk
	On k.id_tpo_kit = tk.id_tpo_kit
	Where tk.id_tpo_kit in (select id_tpo_kit from @Kit_Cpf_Layout)
	Order By 1 desc

	Insert Into @Kit_Xml
	select x.id_kit, x.tx_xml_recebimento
	from [dbo].[tb_kit_xml] x
		JOIN @Kits k
	On x.id_kit = k.id_kit

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		while(@incr <= (select Count(1) from @Temp_anonimizacao_cpf))
		Begin
			
			select @Nr_cpf = Nr_cpf
			from @Temp_anonimizacao_cpf Where Id_anonimizacao = @incr

			select @Kit_Apagar = id_kit from @Kit_Xml where lower(tx_xml_recebimento) like '%Nr_cpf="' + @Nr_cpf + '"%'

			
		delete from tb_kit_xml Where id_kit = @Kit_Apagar
		select @id_documento = id_documento from tb_documento Where id_kit = @Kit_Apagar
		delete from tb_kit_end_documento where id_documento = @id_documento
		delete from tb_documento Where id_kit = @Kit_Apagar
		delete from tb_kit_endereco Where id_kit = @Kit_Apagar
		delete from tb_stt_kit_historico Where id_kit = @Kit_Apagar
		select @id_search = id_search from tb_search Where id_kit = @Kit_Apagar
		delete from tb_det_search where id_search = @id_search
		delete from tb_search Where id_kit = @Kit_Apagar
		delete from tb_kit_item Where id_kit = @Kit_Apagar
		delete from tb_kit_lte_envio Where id_kit = @Kit_Apagar
		delete from tb_kit Where id_kit = @Kit_Apagar
		

		SET @incr = @incr + 1

		End
	End

	set nocount off

end