Use dbmgi

-- exec spAnonimiza_documento_cliente_eMGI 'S'
IF OBJECT_ID('spAnonimiza_documento_cliente_eMGI ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_documento_cliente_eMGI  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Anonimiza todos os dados pessoais dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_documento_cliente_eMGI(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Temp_Det_Sear table
(
vl_key_dominio varchar(150),
id_search bigint
)

declare @Temp_Sear table
(
id_kit bigint
)

	Insert Into @Temp_Det_Sear
	select d.vl_key_dominio, id_search
	from [dbo].[Temp_anonimizacao_cpf] t (nolock)
		JOIN [dbo].[tb_det_search] d (nolock)
	On t.Nr_cpf = d.vl_key_dominio
	Where d.ds_key_dominio = 'Nr_cpf' and d.vl_key_dominio <> ''

	Insert Into @Temp_Sear
	select id_kit
	from @Temp_Det_Sear t
		JOIN [tb_search] d (nolock)
	On t.id_search = d.id_search

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		Update d
		Set vl_key_dominio = '11111111111'
		From @Temp_Det_Sear t
			JOIN [dbo].[tb_det_search] d (nolock)
		On t.id_search = d.id_search
		Where ds_key_dominio = 'Nr_cpf'

		Update d
		Set vl_key_dominio = 'Cliente Anonimizado'
		From @Temp_Det_Sear t
			JOIN [dbo].[tb_det_search] d (nolock)
		On t.id_search = d.id_search
		Where ds_key_dominio = 'Nm_participante'

		Update s
		Set	nm_tit_search = 'Cliente Anonimizado'
			--ds_dad_search = 'Cliente Anonimizado'
		From @Temp_Det_Sear t
			JOIN [tb_search] s
		On t.id_search = s.id_search

		Update k
		Set nm_rsp_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			nm_logradouro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			ds_end_complemento = '',
			nr_logradouro = '1253',
			nm_bairro = 'Berrini',
			nr_cep = '04571010'
		From @Temp_Sear t
			JOIN [dbo].[tb_kit_endereco] k
		On t.id_kit = k.id_kit

	End
	
	set nocount off

end