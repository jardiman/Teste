use dbfindi

IF NOT EXISTS(SELECT 1 FROM dbo.sysobjects WHERE xtype = 'U' AND name = 'Temp_anonimizacao_cpf')
BEGIN
Create Table dbo.Temp_anonimizacao_cpf(
Nr_cpf varchar(20) NOT NULL
)
END