use dbfindi

-- exec spAnonimiza_exclusao_documento_cliente_FCO 'S'
IF OBJECT_ID('spAnonimiza_exclusao_documento_cliente_FCO ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_exclusao_documento_cliente_FCO  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Anonimiza todos os dados pessoais dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_exclusao_documento_cliente_FCO(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Temp_Part_Anoni table
(
id_item int
)

declare @Temp_PRP_Docum table
(
id_proposta_documento int
)

	Insert Into @Temp_Part_Anoni
	select distinct i.id_item
	from Temp_anonimizacao_cpf t (nolock)
		JOIN tb_item i (nolock)
	On t.Nr_cpf = i.Nr_cpf

	Insert Into @Temp_PRP_Docum
	select distinct p.id_proposta_documento
	from @Temp_Part_Anoni t
		JOIN tb_prp_documento p (nolock)
	On t.id_item = p.id_item

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		Delete i
		From @Temp_Part_Anoni t
				JOIN tb_itm_status i
			On i.id_item = t.id_item

		Delete d
		From @Temp_PRP_Docum t
				JOIN tb_pnd_documento d
			On d.id_proposta_documento = t.id_proposta_documento

		Delete p
		From @Temp_Part_Anoni t
				JOIN tb_prp_documento p
			On p.id_item = t.id_item

		Delete p
		From @Temp_Part_Anoni t
				JOIN tb_prp_pendencia_item p
			On p.id_item = t.id_item

		Delete p
		From @Temp_Part_Anoni t
				JOIN tb_item p
			On p.id_item = t.id_item
	End

	set nocount off

end