use dbfindi

-- exec spAnonimiza_documento_cliente_FCO 'N'
IF OBJECT_ID('spAnonimiza_documento_cliente_FCO ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_documento_cliente_FCO  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Anonimiza todos os dados pessoais dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_documento_cliente_FCO(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Temp_Part_Anoni table
(
Nr_cpf NUMERIC(12,0)
)

	insert into @Temp_Part_Anoni
	select distinct Nr_cpf
	from Temp_anonimizacao_cpf t (nolock)

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		Update p
		Set Nr_cpf = '11111111111',
			tx_nome = 'Cliente Anonimizado',
			nr_rg = '',
			tx_email = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN tb_cliente_solucao p
		On p.Nr_cpf = t.Nr_cpf

		Update p
		Set nr_cpf_cnpj = '11111111111',
			tx_rza_social = 'Cliente Anonimizado',
			tx_end_crr_logradouro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			tx_end_cbr_logradouro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			tx_end_crr_bairro = 'Berrini',
			tx_end_cbr_bairro = 'Berrini',
			tx_end_crr_cep = '04571010',
			tx_end_cbr_cep = '04571010',
			tx_end_crr_ddd_telefone = '11',
			tx_end_cbr_ddd_telefone = '11',
			tx_end_crr_telefone = '5505-5800',
			tx_end_cbr_telefone = '5505-5800',
			tx_end_crr_email = 'privacidade@metlife.com.br',
			tx_end_cbr_email = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN tb_cnv_cobranca p
		On p.nr_cpf_cnpj = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_cpf_cnpj = '11111111111',
			tx_nome = 'Cliente Anonimizado',
			tx_cei = 'A CONFIRMAR'
		From @Temp_Part_Anoni t
			JOIN tb_pessoa p
		On p.nr_cpf_cnpj = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_prp_cpf_cnpj = '11111111111',
			tx_prp_nme_rza_social = 'Cliente Anonimizado'
		From @Temp_Part_Anoni t
			JOIN tb_proposta p
		On p.nr_prp_cpf_cnpj = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_cpf = '11111111111',
			tx_nme_participante = 'Cliente Anonimizado'
		From @Temp_Part_Anoni t
			JOIN tb_rco_segurado p
		On p.nr_cpf = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_cpf = '11111111111',
			nm_segurado = 'Cliente Anonimizado'
		From @Temp_Part_Anoni t
			JOIN tb_fco_historico p
		On p.nr_cpf = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_cpf = '11111111111',
			nm_segurado = 'Cliente Anonimizado',
			ds_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			ds_bairro = 'Berrini',
			nr_cep = '04571010',
			nr_ddd = '11',
			nr_telefone = '5505-5800'
		From @Temp_Part_Anoni t
			JOIN tb_fco_mss_sgr_movimentacao p
		On p.nr_cpf = CAST(t.Nr_cpf AS char(14))

		Update p
		Set nr_cpf = '11111111111',
			nm_segurado = 'Cliente Anonimizado',
			ds_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			ds_bairro = 'Berrini',
			nr_cep = '04571010',
			nr_ddd = '11',
			nr_telefone = '5505-5800'
		From @Temp_Part_Anoni t
			JOIN tb_fco_mss_sgr_original p
		On p.nr_cpf = CAST(t.Nr_cpf AS char(14))
	
	End

	if(@Dv_executa_anonimizacao = 'N')
	Begin
		select Count(1)
		from @Temp_Part_Anoni
	End

	set nocount off

end