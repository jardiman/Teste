use dbOdsstage
go

-- exec spSeleciona_documento_disponivel_cliente 'N'
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 18/11/2021
* Núm.Ref. : Projeto Anonimização - LGPD
* Descrição: Seleciona todos os clientes que podem ser anonimizados
* 
**********************************************************************************/
CREATE OR ALTER PROCEDURE dbo.spSeleciona_documento_disponivel_cliente
(
	@Dv_execucao char(1)    = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

If OBJECT_ID('tempdb..#Tb_sistemas_cpfs') is not null drop table #Tb_sistemas_cpfs
create table #Tb_sistemas_cpfs
(
Nr_cpf varchar(20),
Nm_status Char(1)
)
CREATE INDEX idx_cpf ON #Tb_sistemas_cpfs (Nr_cpf);
CREATE INDEX idx_status ON #Tb_sistemas_cpfs (Nr_cpf, Nm_status);

If OBJECT_ID('tempdb..#Temp_nao_anonimiza') is not null drop table #Temp_nao_anonimiza
create table #Temp_nao_anonimiza
(
Nr_cpf varchar(20)
)
CREATE INDEX idx_cpf ON #Temp_nao_anonimiza (Nr_cpf);

	Insert Into #Tb_sistemas_cpfs
	select distinct Nr_cpf, Nm_status
	from LGPD.Tb_sistemas_cpfs
	
	Insert Into #Temp_nao_anonimiza
	select distinct Nr_cpf
	from #Tb_sistemas_cpfs Where Nm_status = 'N'

	delete from #Tb_sistemas_cpfs where Nr_cpf in (select Nr_cpf from #Temp_nao_anonimiza)
	delete from #Tb_sistemas_cpfs where Nr_cpf in (select Nr_cpf from LGPD.Tb_cpfs_vt)

	Insert into LGPD.Tb_documento_cliente
	select distinct Nr_cpf from #Tb_sistemas_cpfs where Nr_cpf not in (select Nr_cpf from LGPD.Tb_documento_cliente)

	Insert into LGPD.Tb_documento_status
	select dc.Id_documento_cliente, 1, null, null, null from LGPD.Tb_documento_cliente dc (nolock)
	Insert into LGPD.Tb_documento_status
	select dc.Id_documento_cliente, 2, null, null, null from LGPD.Tb_documento_cliente dc (nolock)

	set nocount off
end