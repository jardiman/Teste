Use dbecomm

-- exec spAnonimiza_documento_cliente_vida_rees 'S'
IF OBJECT_ID('spAnonimiza_documento_cliente_vida_rees ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_documento_cliente_vida_rees  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Anonimiza todos os dados pessoais dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_documento_cliente_vida_rees(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Temp_Part_Anoni table
(
Nr_cpf Varchar(20)
)

	insert into @Temp_Part_Anoni
	select distinct cs.Nr_cpf
	from Temp_anonimizacao_cpf t (nolock)
		JOIN COVida_segurada cs (nolock)
	On t.Nr_cpf = cs.Nr_cpf

		JOIN COVida_segurada_atual csa (nolock)
	On  csa.Cd_vida			= cs.Cd_vida
	and csa.Nr_versao_vida	= cs.Nr_versao_vida
	where cs.Nr_cpf is not null

	insert into @Temp_Part_Anoni
	select distinct cs.Nr_cnpj
	from Temp_anonimizacao_cpf t (nolock)
		JOIN COApolice_sub_instituidora cs (nolock)
	On t.Nr_cpf = cs.Nr_cnpj

		JOIN COApolice_atual ca (nolock)
	On  ca.Id_apolice_unica	= cs.Id_apolice_unica
	and ca.Nr_versao		= cs.Nr_versao
	where cs.Nr_cnpj is not null

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		
		Update p
		Set Nr_cnpj = '11111111111',
			Nm_sub_instituidora = 'Cliente Anonimizado',
			Nm_principal_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_principal_numero = '1253',
			Nm_principal_bairro = 'Berrini',
			Nm_cobranca_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_cobranca_numero = '1253',
			Nm_cobranca_bairro = 'Berrini',
			Nr_cobranca_cep = '04571010',
			Nm_telefone = '11 5505-5800',
			Nr_cei = 'A CONFIRMAR',
			Nm_contato_email = 'privacidade@metlife.com.br',
			Nm_email_faturamento = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN COApolice_sub_instituidora p
		On p.Nr_cnpj = t.Nr_cpf
		Where p.Cd_status in (2,3)

		Update p
		Set Nr_cpf = '11111111111',
			Nm_vida = 'Cliente Anonimizado',
			Nm_end_funcional1 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_end_funcional2 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_end_funcional3 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_rg = ''
		From @Temp_Part_Anoni t
			JOIN COVida_segurada p
		On p.Nr_cpf = t.Nr_cpf
		Where p.Cd_status in (2,3)

		Update p
		Set Nr_cpf = '11111111111',
			Nm_beneficiario = 'Cliente Anonimizado',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_bairro = 'Berrini',
			Nr_cep = '04571010'
		From @Temp_Part_Anoni t
			JOIN COVida_segurada_beneficiario p
		On p.Nr_cpf = t.Nr_cpf


	End

	if(@Dv_executa_anonimizacao = 'N')
	Begin
		select Count(1)
		from @Temp_Part_Anoni
	End

	set nocount off

end