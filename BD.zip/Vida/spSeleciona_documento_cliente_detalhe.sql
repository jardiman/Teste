use dbecomm
go

--exec spSeleciona_documento_cliente_detalhe null
IF OBJECT_ID('spSeleciona_documento_cliente_detalhe') IS NULL
	EXEC('CREATE Procedure dbo.spSeleciona_documento_cliente_detalhe  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 18/11/2021
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Seleciona todos os clientes que n�o possuem apolice ativa na Metlife n�s ultimos 10 anos
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spSeleciona_documento_cliente_detalhe(
	@Dt_execucao datetime 	= null
)
as

begin
	set ansi_warnings off
	set nocount on

IF 1 = 0
BEGIN
    SELECT
		CONVERT (BIGINT, 123) AS ID,
		CONVERT (varchar (500), 'Nr_cpf') AS Nr_cpf,
		CONVERT (varchar(200), 'Dt_cancelamento') AS Dt_cancelamento
END


/********************************     Preenche Proc spSeleciona_documento_cliente_indv       ************************************************/


	If OBJECT_ID('tempdb..#Temp_Procedure') is not null drop table #Temp_Procedure
	create table #Temp_Procedure
	(
	Nr_cpf varchar(20),
	Nm_status Char(1)
	)
	CREATE INDEX idx_cpf ON #Temp_Procedure (Nr_cpf);
	CREATE INDEX idx_status ON #Temp_Procedure (Nr_cpf, Nm_status);

	Insert into #Temp_Procedure
	exec spSeleciona_documento_cliente_indv null


/********************************************************************************************************************************************/


/********************************     Cria Temps       ************************************************/

If OBJECT_ID('tempdb..#Lista_Apolice') is not null drop table #Lista_Apolice
Create table #Lista_Apolice
(
Cd_administradora smallint,
Cd_filial smallint,
Cd_produto smallint,
Cd_convenio int,
Cd_apolice numeric(7,0),
Cd_sub_instituidora int
)
CREATE INDEX idx_conv ON #Lista_Apolice (Cd_administradora, Cd_filial, Cd_produto, Cd_convenio, Cd_sub_instituidora);
CREATE INDEX idx_apol ON #Lista_Apolice (Cd_administradora, Cd_filial, Cd_produto, Cd_apolice, Cd_sub_instituidora);

--#Temp_Prop_Canc
If OBJECT_ID('tempdb..#Lista_Cpfs_canc') is not null drop table #Lista_Cpfs_canc
Create table #Lista_Cpfs_canc
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_canc (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Cpfs_ativ') is not null drop table #Lista_Cpfs_ativ
Create table #Lista_Cpfs_ativ
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_ativ (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Sinistro') is not null drop table #Lista_Sinistro
Create table #Lista_Sinistro
(
Cd_administradora smallint,
Cd_filial smallint,
Cd_ramo smallint,
Cd_comunicacao int,
Nr_cpf varchar(15),
Dt_movimentacao datetime,
)
CREATE INDEX idx_sinit ON #Lista_Sinistro (Cd_administradora, Cd_filial, Cd_ramo, Cd_comunicacao, Dt_movimentacao);

If OBJECT_ID('tempdb..#Lista_Cpfs_sinistro_excluir') is not null drop table #Lista_Cpfs_sinistro_excluir
Create table #Lista_Cpfs_sinistro_excluir
(
Nr_cpf varchar(15)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_sinistro_excluir (Nr_cpf);


/******************************************************************************************************/


declare
@Busca			datetime,
@Busca_inclusao	datetime
	
	if(@Dt_execucao is null) begin set @Dt_execucao = getdate() end
	set @Busca = dateadd(year, -10, convert(varchar(10), @Dt_execucao, 120))
	set @Busca_inclusao = dateadd(year, -10, convert(varchar(10), getdate(), 120))


/********************************  Classico: Preenche as temps canceladas  ************************************************/


	insert into #Lista_Apolice
	select co.Cd_administradora, co.Cd_filial, co.Cd_produto, co.Cd_convenio, csi.Cd_apolice, csi.Cd_sub_instituidora 
	from Convenio co (nolock)
		JOIN Convenio_sub_instituidora csi (nolock)
	On  co.Cd_convenio			= csi.Cd_convenio

		JOIN Produto pro (nolock)
	On  pro.Cd_administradora	= csi.Cd_administradora
	and pro.Cd_produto			= csi.Cd_produto
	Where pro.Cd_classe_produto in (2, 3, 7, 8)

	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) <= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where Isnull(pro.Dt_registro_cancelamento, pro.Dt_cancelamento) <= @Busca and pro.Dv_status <> 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/**************************************************************************************************************************/


/********************************  Reestruturado: Preenche as temps canceladas  ************************************************/


	Insert Into #Lista_Cpfs_canc
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_registro_cancelamento <= @Busca and co.Cd_status  <> 1 and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11

	Insert Into #Lista_Cpfs_canc
	select REPLACE (REPLACE (cs.Nr_cpf, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao

		JOIN COVida_segurada_apolice csa (nolock)
	On  csi.Id_apolice_unica	= csa.Id_apolice_unica
	and csi.Nr_versao			= csa.Nr_versao
	and csi.Cd_sub_instituidora	= csa.Cd_sub_instituidora

		JOIN COVida_segurada_atual cosa (nolock)
	On  csa.Cd_vida			= cosa.Cd_vida
	and csa.Nr_versao_vida	= cosa.Nr_versao_vida

		JOIN COVida_segurada cs (nolock)
	On  cosa.Cd_vida			= cs.Cd_vida
	and cosa.Nr_versao_vida	= cs.Nr_versao_vida
	Where isnull(cs.Dt_registro_cancelamento, cs.Dt_exclusao) <= @Busca and cs.Cd_status <> 1 and cs.Nr_cpf is not null and cs.Nr_cpf <> '11111111111' and cs.Nr_cpf <> '' and len(cs.Nr_cpf) <= 11



/*******************************************************************************************************************************/



/********************************  Classico: Preenche as temps ativas  ************************************************/


	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where csi.Dt_inclusao >= @Busca_inclusao and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) is null and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_inclusao >= @Busca_inclusao and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where Isnull(pro.Dt_registro_cancelamento, pro.Dt_cancelamento) is null and pro.Dv_status = 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/************************************************************************************************************/


/********************************  Reestruturado: Preenche as temps ativas  ************************************************/


	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_registro_cancelamento is null and co.Cd_status = 1 and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11

	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_inclusao >= @Busca_inclusao and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11

	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (cs.Nr_cpf, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao

		JOIN COVida_segurada_apolice csa (nolock)
	On  csi.Id_apolice_unica	= csa.Id_apolice_unica
	and csi.Nr_versao			= csa.Nr_versao
	and csi.Cd_sub_instituidora	= csa.Cd_sub_instituidora

		JOIN COVida_segurada_atual cosa (nolock)
	On  csa.Cd_vida			= cosa.Cd_vida
	and csa.Nr_versao_vida	= cosa.Nr_versao_vida

		JOIN COVida_segurada cs (nolock)
	On  cosa.Cd_vida			= cs.Cd_vida
	and cosa.Nr_versao_vida	= cs.Nr_versao_vida
	Where isnull(cs.Dt_registro_cancelamento, cs.Dt_exclusao) is null and cs.Cd_status = 1 and cs.Nr_cpf is not null and cs.Nr_cpf <> '11111111111' and cs.Nr_cpf <> '' and len(cs.Nr_cpf) <= 11

	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (cs.Nr_cpf, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao

		JOIN COVida_segurada_apolice csa (nolock)
	On  csi.Id_apolice_unica	= csa.Id_apolice_unica
	and csi.Nr_versao			= csa.Nr_versao
	and csi.Cd_sub_instituidora	= csa.Cd_sub_instituidora

		JOIN COVida_segurada_atual cosa (nolock)
	On  csa.Cd_vida			= cosa.Cd_vida
	and csa.Nr_versao_vida	= cosa.Nr_versao_vida

		JOIN COVida_segurada cs (nolock)
	On  cosa.Cd_vida			= cs.Cd_vida
	and cosa.Nr_versao_vida	= cs.Nr_versao_vida
	Where cs.Dt_inclusao >= @Busca_inclusao and cs.Nr_cpf is not null and cs.Nr_cpf <> '11111111111' and cs.Nr_cpf <> ''and len(cs.Nr_cpf) <= 11


/***************************************************************************************************************************/


/********************************  Preenche as temps sinistro  ************************************************/


	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) is not null and isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) is not null and isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	Where ls.Dt_movimentacao <= @Busca
	Group By ls.Nr_cpf
	Having Sum( IsNull( sca.Vl_movimentacao, 0 ) + ( IsNull( sca.Vl_correcaoMonetaria, 0 ) + IsNull( sca.Vl_multa, 0 ) + IsNull( sca.Vl_juros, 0 ) ) ) > 0

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	Where ls.Dt_movimentacao >= @Busca_inclusao
	Group By ls.Nr_cpf


/**************************************************************************************************************/

/********************************  Gerar Carga de CPFs  ************************************************/


	Insert into #Lista_Cpfs_canc select Nr_cpf from #Temp_Procedure where Nm_status = 'S'
	Insert into #Lista_Cpfs_ativ select Nr_cpf from #Temp_Procedure where Nm_status = 'N'
	Insert into #Lista_Cpfs_ativ select Nr_cpf from #Lista_Cpfs_sinistro_excluir
	delete from #Lista_Cpfs_canc where Nr_cpf IN (select Nr_cpf from #Lista_Cpfs_ativ)

	select distinct 'C' as Dv_sistema, prod.Cd_classe_produto, null as Cd_vida, null as Nr_versao_vida, pro.Cd_administradora, pro.Cd_filial, pro.Cd_produto, Cd_proposta, Cast(Nr_cpf as Varchar(20)), Nm_participante, Nm_endereco, Nm_cidade, Cd_uf, Nr_cep, Nr_telefone, Nr_documento, null as Nm_cei, Dt_nascimento, Nm_email
	from Proposta pro (nolock)
		JOIN Participante pa (nolock)
	On  pa.Cd_administradora	= pro.Cd_administradora
	and pa.Cd_filial			= pro.Cd_filial
	and pa.Cd_participante		= pro.Cd_participante

		JOIN Produto prod (nolock)
	On  prod.Cd_administradora	= pro.Cd_administradora
	and prod.Cd_produto			= pro.Cd_produto
	Where pa.Nr_cpf in (select Nr_cpf From #Lista_Cpfs_canc)
	union all
	select distinct 'R' as Dv_sistema, prod.Cd_classe_produto, cosa.Cd_vida, cosa.Nr_versao_vida, co.Cd_administradora, co.Cd_filial, co.Cd_produto, null as Cd_proposta, Nr_cpf, Nm_vida, Nm_end_funcional1, Nm_end_funcional2, null as Cd_uf, null as Nr_cep, null as Nr_telefone, Nr_rg, null as Nm_cei, Dt_nascimento, null as Nm_email
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN Produto prod (nolock)
	On  prod.Cd_administradora	= co.Cd_administradora
	and prod.Cd_produto			= co.Cd_produto

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao

		JOIN COVida_segurada_apolice csa (nolock)
	On  csi.Id_apolice_unica	= csa.Id_apolice_unica
	and csi.Nr_versao			= csa.Nr_versao
	and csi.Cd_sub_instituidora	= csa.Cd_sub_instituidora

		JOIN COVida_segurada_atual cosa (nolock)
	On  csa.Cd_vida			= cosa.Cd_vida
	and csa.Nr_versao_vida	= cosa.Nr_versao_vida

		JOIN COVida_segurada cs (nolock)
	On  cosa.Cd_vida			= cs.Cd_vida
	and cosa.Nr_versao_vida	= cs.Nr_versao_vida
	Where len(cs.Nr_cpf) <= 11 and REPLACE (REPLACE (cs.Nr_cpf, '.',''), '-', '') in (select Nr_cpf From #Lista_Cpfs_canc)

	
/*******************************************************************************************************/

	set nocount off

end