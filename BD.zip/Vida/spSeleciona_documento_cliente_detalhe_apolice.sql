use dbecomm
go

--exec spSeleciona_documento_cliente_detalhe_apolice null
IF OBJECT_ID('spSeleciona_documento_cliente_detalhe_apolice ') IS NULL
	EXEC('CREATE Procedure dbo.spSeleciona_documento_cliente_detalhe_apolice  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 18/11/2021
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Seleciona todos os clientes que n�o possuem apolice ativa na Metlife n�s ultimos 10 anos
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spSeleciona_documento_cliente_detalhe_apolice(
	@Dt_execucao datetime 	= null
)
as

begin
	set ansi_warnings off
	set nocount on

If OBJECT_ID('tempdb..#Lista_Cpfs_canc') is not null drop table #Lista_Cpfs_canc
Create table #Lista_Cpfs_canc
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_canc (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Cpfs_ativ') is not null drop table #Lista_Cpfs_ativ
Create table #Lista_Cpfs_ativ
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_ativ (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Sinistro') is not null drop table #Lista_Sinistro
Create table #Lista_Sinistro
(
Cd_administradora smallint,
Cd_filial smallint,
Cd_ramo smallint,
Cd_comunicacao int,
Nr_cpf varchar(15),
Dt_movimentacao datetime,
)
CREATE INDEX idx_sinit ON #Lista_Sinistro (Cd_administradora, Cd_filial, Cd_ramo, Cd_comunicacao, Dt_movimentacao);

If OBJECT_ID('tempdb..#Lista_Cpfs_sinistro_excluir') is not null drop table #Lista_Cpfs_sinistro_excluir
Create table #Lista_Cpfs_sinistro_excluir
(
Nr_cpf varchar(15)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_sinistro_excluir (Nr_cpf);

declare
@Busca			datetime,
@Busca_inclusao	datetime
	
	if(@Dt_execucao is null) begin set @Dt_execucao = getdate() end
	set @Busca = dateadd(year, -10, convert(varchar(10), @Dt_execucao, 120))
	set @Busca_inclusao = dateadd(year, -10, convert(varchar(10), getdate(), 120))


/********************************  Preenche as temps canceladas  ************************************************/


	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) <= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null


	Insert Into #Lista_Cpfs_canc
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_registro_cancelamento <= @Busca and co.Cd_status  <> 1 and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11


/****************************************************************************************************************/


/********************************  Preenche as temps ativas  ************************************************/


	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where csi.Dt_inclusao >= @Busca_inclusao and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) is null and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_registro_cancelamento is null and co.Cd_status = 1 and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11

	Insert Into #Lista_Cpfs_ativ
	select REPLACE (REPLACE (csi.Nr_cnpj, '.',''), '-', '')
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao
	Where csi.Dt_inclusao >= @Busca_inclusao and csi.Nr_cnpj is not null and csi.Nr_cnpj <> '11111111111' and csi.Nr_cnpj <> '' and Len(csi.Nr_cnpj) <= 11


/************************************************************************************************************/


/********************************  Preenche as temps sinistro  ************************************************/


	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) is not null and isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) is not null and isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	Where ls.Dt_movimentacao <= @Busca
	Group By ls.Nr_cpf
	Having Sum( IsNull( sca.Vl_movimentacao, 0 ) + ( IsNull( sca.Vl_correcaoMonetaria, 0 ) + IsNull( sca.Vl_multa, 0 ) + IsNull( sca.Vl_juros, 0 ) ) ) > 0

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	Where ls.Dt_movimentacao >= @Busca_inclusao
	Group By ls.Nr_cpf


/**************************************************************************************************************/


	Insert into #Lista_Cpfs_ativ select Nr_cpf from #Lista_Cpfs_sinistro_excluir
	delete from #Lista_Cpfs_canc where Nr_cpf IN (select Nr_cpf from #Lista_Cpfs_ativ)

	select distinct 'C' as Dv_sistema, pro.Cd_classe_produto, null as Id_apolice_unica, null as Nr_versao, csi.Cd_administradora, csi.Cd_filial, csi.Cd_produto, csi.Cd_ramo, Cd_convenio, Cd_apolice, ist.Cd_instituidora, Nm_instituidora as Nm_apolice, ist.Nr_cpf, Nm_endereco, Nm_cidade, null as Cd_uf, Nm_cep as Nr_cep, Nm_fone as Nr_telefone, ist.Nm_cei, Nm_email
	from Convenio_sub_instituidora csi (nolock)
		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora

		JOIN Produto pro (nolock)
	On  pro.Cd_administradora	= csi.Cd_administradora
	and pro.Cd_produto			= csi.Cd_produto
	Where ist.Nr_cpf in (select Nr_cpf From #Lista_Cpfs_canc)
	Union all
	select distinct 'R' as Dv_sistema, pro.Cd_classe_produto, co.Id_apolice_unica, co.Nr_versao, co.Cd_administradora, co.Cd_filial, co.Cd_produto, co.Cd_ramo, Cd_convenio, Cd_apolice, csi.Cd_instituidora, Nm_sub_instituidora as Nm_apolice, csi.Nr_cnpj as Nr_cgc, Nm_principal_endereco as Nm_endereco, Nm_principal_cidade as Nm_cidade, Cd_principal_uf as Cd_uf, Nm_principal_cep as Nr_cep, Nm_telefone as Nr_telefone, Nr_cei as Nm_cei, Nm_contato_email as Nm_email
	from COApolice co (nolock)
		JOIN COApolice_atual coa (nolock)
	On  co.Id_apolice_unica	= coa.Id_apolice_unica
	and co.Nr_versao		= coa.Nr_versao

		JOIN COApolice_sub_instituidora csi (nolock)
	On  co.Id_apolice_unica	= csi.Id_apolice_unica
	and co.Nr_versao		= csi.Nr_versao

		JOIN Produto pro (nolock)
	On  pro.Cd_administradora	= co.Cd_administradora
	and pro.Cd_produto			= co.Cd_produto
	Where Len(csi.Nr_cnpj) <= 11 and csi.Nr_cnpj in (select Nr_cpf From #Lista_Cpfs_canc)

	set nocount off

end