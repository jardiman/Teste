Use dbecomm

-- exec spAnonimiza_documento_cliente_vida 'S'
IF OBJECT_ID('spAnonimiza_documento_cliente_vida ') IS NULL
	EXEC('CREATE Procedure dbo.spAnonimiza_documento_cliente_vida  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 31/01/2022
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Anonimiza todos os dados pessoais dos clientes com mais de 10 anos contrato com a Metlife.
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spAnonimiza_documento_cliente_vida(
	@Dv_executa_anonimizacao char(1) = 'N'
)
as

begin
	set ansi_warnings off
	set nocount on

declare @Temp_Part_Anoni table
(
Nr_cpf NUMERIC(12,0)
)

	insert into @Temp_Part_Anoni
	select distinct p.Nr_cpf
	from Temp_anonimizacao_cpf t (nolock)
		JOIN Participante p (nolock)
	On t.Nr_cpf = p.Nr_cpf
	where p.Nr_cpf is not null

	insert into @Temp_Part_Anoni
	select distinct ist.Nr_cpf
	from Temp_anonimizacao_cpf t (nolock)
		JOIN Instituidora ist (nolock)
	On t.Nr_cpf = ist.Nr_cpf
	where ist.Nr_cpf is not null

	if(@Dv_executa_anonimizacao = 'S')
	Begin
		Update p
		Set Nr_cpf = '11111111111',
			Nm_instituidora = 'Cliente Anonimizado',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_bairro = 'Berrini',
			Nm_cep = '04571010',
			Nm_cep_cobranca = '04571010',
			Nm_fone = '11 5505-5800',
			Nm_fax = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN Instituidora p
		On p.Nr_cpf = t.Nr_cpf
		
		Update p
		Set Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nr_documento = '',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_outro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_cep = '04571010',
			Nr_cep_cobranca = '04571010',
			Nr_cep_outro = '04571010',
			Nr_telefone = '11 5505-5800',
			Nr_telefone_cel = '11 5505-5800',
			Nr_telefone_com = '11 5505-5800',
			Nr_telefone_outro = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN Participante p
		On p.Nr_cpf = t.Nr_cpf

		Update p
		Set	Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nr_documento = '',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_cep = '04571010',
			Nr_cep_cobranca = '04571010',
			Nr_telefone = '11 5505-5800',
			Nr_telefone_cel = '11 5505-5800',
			Nr_telefone_com = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		from @Temp_Part_Anoni t
			JOIN Temp_proposta_participante p
		On p.Nr_cpf = t.Nr_cpf

		Update p
		Set Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nr_documento = '',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_cep = '04571010',
			Nr_cep_cobranca = '04571010',
			Nr_telefone = '11 5505-5800',
			Nr_telefone_cel = '11 5505-5800',
			Nr_telefone_com = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		from @Temp_Part_Anoni t
			JOIN CBEdita_participante p
		On p.Nr_cpf = t.Nr_cpf


		Update p
		SET Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_bairro = 'Berrini',
			Nm_end_funcional1 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_end_funcional2 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_end_funcional3 = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_cep = '04571010',
			Nm_telefone = '11 5505-5800'
		from @Temp_Part_Anoni t
			JOIN Alterar_participantes p
		On p.Nr_cpf = t.Nr_cpf


		Update p
		SET Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nr_documento = '',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_cep = '04571010',
			Nr_cep_cobranca = '04571010',
			Nr_telefone = '11 5505-5800',
			Nr_telefone_cel = '11 5505-5800',
			Nr_telefone_com = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		from @Temp_Part_Anoni t
			JOIN CBEdita_participante p
		On p.Nr_cpf = t.Nr_cpf


		Update p
		SET CPF_participante = '11111111111',
			Nome_participante = 'Cliente Anonimizado',
			Logradouro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Numero = '1253',
			Complemento = '',
			Bairro = 'Berrini',
			CEP = '04571010',
			DDD_residencial = '11',
			Telefone_residencial = '5505-5800',
			DDD_comercial = '11',
			Telefone_comercial = '5505-5800',
			DDD_celular = '11',
			Telefone_celular = '5505-5800',
			Email_1 = 'privacidade@metlife.com.br',
			Email_2 = 'privacidade@metlife.com.br'
		from @Temp_Part_Anoni t
			JOIN Dados_uploader p
		On p.CPF_participante = t.Nr_cpf


		Update p
		Set Nr_cpf = '11111111111',
			Nm_participante = 'Cliente Anonimizado',
			Nr_documento = '',
			Nm_endereco = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nm_endereco_outro = 'Av. Engenheiro Luis Carlos Berrini, 1253',
			Nr_cep = '04571010',
			Nr_cep_cobranca = '04571010',
			Nr_cep_outro = '04571010',
			Nr_telefone = '11 5505-5800',
			Nr_telefone_cel = '11 5505-5800',
			Nr_telefone_com = '11 5505-5800',
			Nr_telefone_outro = '11 5505-5800',
			Nm_email = 'privacidade@metlife.com.br'
		From @Temp_Part_Anoni t
			JOIN INEdita_participante p
		On p.Nr_cpf = t.Nr_cpf


	Update p
	SET Nr_cpf = '11111111111',
		Nm_participante = 'Cliente Anonimizado',
		Nr_rg = '',
		Nm_endereco_cobranca = 'Av. Engenheiro Luis Carlos Berrini, 1253',
		Nm_bairro_cobranca = 'Berrini',
		Nr_cep_cobranca = '04571010',
		Nm_ddd = '11',
		Nr_telefone = '5505-5800',
		Nm_ddd_fax = '11',
		Nr_fax = '5505-5800',
		Nm_ddd_com = '11',
		Nr_telefone_com = '5505-5800'
	From @Temp_Part_Anoni t
			JOIN Pie_interface_detalhe p
		On p.Nr_cpf = t.Nr_cpf

	End

	if(@Dv_executa_anonimizacao = 'N')
	Begin
		select Count(1)
		from @Temp_Part_Anoni
	End

	set nocount off

end