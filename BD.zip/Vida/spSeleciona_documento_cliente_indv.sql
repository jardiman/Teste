use dbecomm
go

--exec spSeleciona_documento_cliente_indv null
IF OBJECT_ID('spSeleciona_documento_cliente_indv') IS NULL
	EXEC('CREATE Procedure dbo.spSeleciona_documento_cliente_indv  AS')
GO
/**********************************************************************************
* Senior Solution
*==================================================================================
* Autor ...: Andre Jardim
* Data ....: 18/11/2021
* N�m.Ref. : Projeto Anonimiza��o - LGPD
* Descri��o: Seleciona todos os clientes que n�o possuem apolice ativa na Metlife n�s ultimos 10 anos
* 
**********************************************************************************/
ALTER PROCEDURE dbo.spSeleciona_documento_cliente_indv(
	@Dt_execucao datetime 	= null
)
as

begin
	set ansi_warnings off
	set nocount on

IF 1 = 0
BEGIN
    SELECT
		CONVERT (BIGINT, 123) AS ID,
		CONVERT (varchar (500), 'Nr_cpf') AS Nr_cpf,
		CONVERT (varchar(200), 'Dt_cancelamento') AS Dt_cancelamento
END


/********************************     Cria Temps       ************************************************/

If OBJECT_ID('tempdb..#Lista_Apolice') is not null drop table #Lista_Apolice
Create table #Lista_Apolice
(
Cd_administradora smallint,
Cd_filial smallint,
Cd_produto smallint,
Cd_convenio int,
Cd_apolice numeric(7,0),
Cd_sub_instituidora int
)
CREATE INDEX idx_conv ON #Lista_Apolice (Cd_administradora, Cd_filial, Cd_produto, Cd_convenio, Cd_sub_instituidora);
CREATE INDEX idx_apol ON #Lista_Apolice (Cd_administradora, Cd_filial, Cd_produto, Cd_apolice, Cd_sub_instituidora);

If OBJECT_ID('tempdb..#Lista_Cpfs_canc') is not null drop table #Lista_Cpfs_canc
Create table #Lista_Cpfs_canc
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_canc (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Cpfs_ativ') is not null drop table #Lista_Cpfs_ativ
Create table #Lista_Cpfs_ativ
(
Nr_cpf NUMERIC(12,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_ativ (Nr_cpf);

If OBJECT_ID('tempdb..#Lista_Cpfs_prop') is not null drop table #Lista_Cpfs_prop
Create table #Lista_Cpfs_prop
(
Nr_cpf NUMERIC(12,0),
Cd_proposta NUMERIC(9,0)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_prop (Nr_cpf);
CREATE INDEX idx_prop ON #Lista_Cpfs_prop (Cd_proposta);
CREATE INDEX idx_chave ON #Lista_Cpfs_prop (Nr_cpf, Cd_proposta);

If OBJECT_ID('tempdb..#Lista_Sinistro') is not null drop table #Lista_Sinistro
Create table #Lista_Sinistro
(
Cd_administradora smallint,
Cd_filial smallint,
Cd_ramo smallint,
Cd_comunicacao int,
Nr_cpf varchar(15),
Dt_movimentacao datetime,
)
CREATE INDEX idx_sinit ON #Lista_Sinistro (Cd_administradora, Cd_filial, Cd_ramo, Cd_comunicacao, Dt_movimentacao);

If OBJECT_ID('tempdb..#Lista_Cpfs_sinistro_excluir') is not null drop table #Lista_Cpfs_sinistro_excluir
Create table #Lista_Cpfs_sinistro_excluir
(
Nr_cpf varchar(15)
)
CREATE INDEX idx_cpf ON #Lista_Cpfs_sinistro_excluir (Nr_cpf);


/******************************************************************************************************/


declare
@Busca			datetime,
@Busca_inclusao	datetime
	
	if(@Dt_execucao is null) begin set @Dt_execucao = getdate() end
	set @Busca = dateadd(year, -20, convert(varchar(10), @Dt_execucao, 120))
	set @Busca_inclusao = dateadd(year, -10, convert(varchar(10), getdate(), 120))


/********************************  Preenche as temps canceladas  ************************************************/


	insert into #Lista_Apolice
	select co.Cd_administradora, co.Cd_filial, co.Cd_produto, co.Cd_convenio, csi.Cd_apolice, csi.Cd_sub_instituidora 
	from Convenio co (nolock)
		JOIN Convenio_sub_instituidora csi (nolock)
	On  co.Cd_convenio			= csi.Cd_convenio

		JOIN Produto pro (nolock)
	On  pro.Cd_administradora	= csi.Cd_administradora
	and pro.Cd_produto			= csi.Cd_produto
	Where pro.Cd_classe_produto in (1, 9, 10)

	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) <= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_canc
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where Isnull(pro.Dt_registro_cancelamento, pro.Dt_cancelamento) <= @Busca and pro.Dv_status <> 'E' and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/****************************************************************************************************************/


/********************************  Preenche as temps ativas  ************************************************/


	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where csi.Dt_inclusao >= @Busca_inclusao and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) >= @Busca and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (ist.Nr_cpf, '.',''), '-', '')
	from #Lista_Apolice l
		JOIN Convenio_sub_instituidora csi (nolock)
	On  l.Cd_convenio			= csi.Cd_convenio

		JOIN Instituidora ist (nolock)
	On  ist.Cd_administradora	= csi.Cd_administradora
	and ist.Cd_filial			= csi.Cd_filial
	and ist.Cd_instituidora		= csi.Cd_sub_instituidora
	Where Isnull(csi.Dt_registro_cancelamento, csi.Dt_cancelamento) is null and ist.Nr_cpf is not null and ist.Nr_cpf <> '11111111111' and ist.Nr_cgc is null

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pro.Dt_inclusao >= @Busca_inclusao and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where Isnull(pro.Dt_registro_cancelamento, pro.Dt_cancelamento) >= @Busca and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Cpfs_ativ
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', '')
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where Isnull(pro.Dt_registro_cancelamento, pro.Dt_cancelamento) is null and pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'


/************************************************************************************************************/


/********************************  Preenche as temps sinistro  ************************************************/


	Insert Into #Lista_Cpfs_prop
	select distinct REPLACE (REPLACE (pa.Nr_cpf, '.',''), '-', ''), pro.Cd_proposta
	From #Lista_Apolice l
		JOIN Proposta pro (nolock)
	On  l.Cd_convenio		= pro.Cd_convenio

		JOIN Participante pa (nolock)
	On  pro.Cd_administradora	= pa.Cd_administradora
	and pro.Cd_filial			= pa.Cd_filial
	and pro.Cd_participante		= pa.Cd_participante
	Where pa.Nr_cpf is not null and pa.Nr_cpf <> '11111111111'

	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) is not null and isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cpf_segurado_sinistrado, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) as Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao
	Where isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) is not null and isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual) <> '' and Len(isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual)) <= 12
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, isnull(Nr_cnpj_cpf_solicitante, Nr_cpf_segurado_manual), sca.Cd_comunicacao

	Insert Into #Lista_Sinistro
	select sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, sca.Cd_comunicacao, prop.Nr_cpf, Max(sca.Dt_movimentacao) as Dt_movimentacao
	From Sinistro s (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  s.Cd_administradora	= sca.Cd_administradora
	and s.Cd_filial			= sca.Cd_filial
	and s.Cd_ramo			= sca.Cd_ramo
	and s.Cd_produto		= sca.Cd_produto
	and s.Cd_comunicacao	= sca.Cd_comunicacao

		JOIN #Lista_Cpfs_prop prop
	On  s.Cd_proposta = prop.Cd_proposta
	Group By sca.Cd_administradora, sca.Cd_filial, sca.Cd_ramo, prop.Nr_cpf, sca.Cd_comunicacao

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	--Where ls.Dt_movimentacao <= @Busca
	Group By ls.Nr_cpf
	Having Sum( IsNull( sca.Vl_movimentacao, 0 ) + ( IsNull( sca.Vl_correcaoMonetaria, 0 ) + IsNull( sca.Vl_multa, 0 ) + IsNull( sca.Vl_juros, 0 ) ) ) > 0

	Insert Into #Lista_Cpfs_sinistro_excluir
	select REPLACE (REPLACE (ls.Nr_cpf, '.',''), '-', '')
	From #Lista_Sinistro ls (nolock)
		JOIN Sinistro_cobertura_avaliacao sca (nolock)
	On  ls.Cd_administradora	= sca.Cd_administradora
	and ls.Cd_filial			= sca.Cd_filial
	and ls.Cd_ramo				= sca.Cd_ramo
	and ls.Cd_comunicacao		= sca.Cd_comunicacao
	and ls.Dt_movimentacao		= sca.Dt_movimentacao
	Where ls.Dt_movimentacao >= @Busca_inclusao
	Group By ls.Nr_cpf


/**************************************************************************************************************/

/********************************  Gerar Carga de CPFs  ************************************************/

	Insert into #Lista_Cpfs_ativ select Nr_cpf from #Lista_Cpfs_sinistro_excluir
	delete from #Lista_Cpfs_canc where Nr_cpf IN (select Nr_cpf from #Lista_Cpfs_ativ)

	-- Anonimiza
	select distinct Nr_cpf, 'S'
	From #Lista_Cpfs_canc where dbo.fnCPF_VALIDO(Cast(Nr_cpf as Varchar)) = 'S'
	Union all
	-- N�o Anonimiza
	select distinct Nr_cpf, 'N'
	From #Lista_Cpfs_ativ

/*******************************************************************************************************/

	set nocount off

end