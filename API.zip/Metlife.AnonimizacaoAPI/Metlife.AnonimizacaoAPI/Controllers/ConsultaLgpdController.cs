﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Web.Http.Description;
using System.Text.Json;
using System.Threading.Tasks;
using Metlife.AnonimizacaoAPI.Models;
using System.Linq;

namespace Metlife.AnonimizacaoAPI.Controllers
{
    [RoutePrefix("api/v1/lgpd/party")]
    public class ConsultaLgpdController : ApiController
    {
        public static List<CpfDocumento> cpfs = new List<CpfDocumento>();
        public static List<Sistemas> sistemas = new List<Sistemas>();
        public static List<ListaAnonimizacao> lista = new List<ListaAnonimizacao>();
        public static List<object> retorno = new List<object>();


        /// <remarks>
        /// Description:
        /// 
        /// Retorna a lista de CPFs a serem anonimizados.
        ///     
        /// </remarks>
        /// <response code="200">Success</response>
        /// <response code="400">Bad Request</response>
        /// <response code="403">Error</response>
        /// <response code="500">Internal Server Error</response>
        [AllowAnonymous]
        [Route("client")]
        [ResponseType(typeof(ExemploListaAnonimizacao))]
        [HttpGet]
        public object ListaAnonimizacao(int Sistema)
        {
            try
            {
                sistemas.Clear();
                cpfs.Clear();
                lista.Clear();
                CargaAnonimizacao.ListaSistemas(Sistema);
                CargaAnonimizacao.ListaCpfs();

                foreach (CpfDocumento cpf in cpfs)
                {
                    lista.Add(new ListaAnonimizacao(sistemas[0].Sistema, cpf.Cpf));
                }

                if (cpfs.Count() == 0) { return NotFound(); }

                Documento doc = new Documento(lista);

                return Ok(JsonConvert.SerializeObject(doc, Newtonsoft.Json.Formatting.None));

            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }


        /// <remarks>
        /// Description:
        /// 
        /// Inseri os CPFs que foram anonimizados.
        ///     
        /// </remarks>
        /// <response code="200">Success</response>
        /// <response code="400">Bad Request</response>
        /// <response code="403">Error</response>
        /// <response code="500">Internal Server Error</response>
        [AllowAnonymous]
        [Route("client")]
        [ResponseType(typeof(ExemploListaAtualizaAnonimizacao))]
        [HttpPost]
        public object AtualizaAnonimizacao(String jsonString)
        {
            try
            {
                retorno.Clear();
                Root dadosAnonimizacao = System.Text.Json.JsonSerializer.Deserialize<Root>(jsonString);

                foreach (DadosAnonimizacao r in (dadosAnonimizacao.Documentos))
                {
                    CargaAnonimizacao.GravaAnonimizacaoNovo(r.Sistema, r.Cpf, r.Status, r.Observacao);
                }

                if ((dadosAnonimizacao.Documentos).Count() == 0) { return NotFound(); }

                return Ok("Dados inseridos com sucesso!");

            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        public class ExemploListaAnonimizacao
        {
            [Display(Name = "Sistema")]
            public int Sistema { get; set; }
        }

        public class ExemploListaAtualizaAnonimizacao
        {
            [Display(Name = "Documentos")]
            public List<DadosAnonimizacao> Documentos { get; set; }
        }
    }
}