﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Newtonsoft.Json;
using Metlife.AnonimizacaoAPI.Models;
using System.Threading.Tasks;
using System.Web.Http.Description;
using System.ComponentModel.DataAnnotations;

namespace Metlife.AnonimizacaoAPI.Controllers
{
    [RoutePrefix("api/Schemas")]
    public class SchemasController : ApiController
    {
        public static List<SchemaSistemas> sistemas = new List<SchemaSistemas>();


        /// <remarks>
        /// Description:
        /// 
        /// Estrutura da Tabela "LGPD.Tb_sistemas" no database
        ///     
        /// </remarks>
        /// <response code="200">Success</response>
        /// <response code="400">Bad Request</response>
        [AllowAnonymous]
        [Route("Tb_sistemas")]
        [ResponseType(typeof(ExemploTb_sistemas))]
        [HttpGet]
        public object Tb_sistemas()
        {
            //object idSis = null; object nmSis = null;
            //SchemaSistemas schemaSistemas = new SchemaSistemas(idSis, nmSis);
            //SchemaCargaDados.Sistemas();

            string retorno = @"{""Tb_sistemas"":[{""Id_sistemas"": 1;""Nm_sistemas"": ""eSeg VIDA"";},{""Id_sistemas"": 2;""Nm_sistemas"": ""eSeg Sinistro"";},{""Id_sistemas"": 3;""Nm_sistemas"": ""eSeg Previdencia"";}]}";

            return Json(retorno);
        }


        /// <remarks>
        /// Description:
        /// 
        /// Estrutura da Tabela "LGPD.Tb_status_anonimizacao" no database
        ///     
        /// </remarks>
        /// <response code="200">Success</response>
        /// <response code="400">Bad Request</response>
        [AllowAnonymous]
        [Route("Tb_status_anonimizacao")]
        [ResponseType(typeof(ExemploTb_status_anonimizacao))]
        [HttpGet]
        public object Tb_status_anonimizacao()
        {
            string retorno = @"{""Tb_status_anonimizacao"": [{""Id_status_anonimizacao"": ""S"";""Nm_status_anonimizacao"": ""Anonimizado"";},{""Id_status_anonimizacao"": ""N"";""Nm_status_anonimizacao"": ""Nao Anonimizado"";}]}";

            return Json(retorno);
        }

        public class ExemploTb_sistemas
        {
            [Display(Name = "Id_sistemas")]
            public int Id_sistemas { get; set; }

            [Display(Name = "Nm_sistemas")]
            public string Nm_sistemas { get; set; }
        }

        public class ExemploTb_status_anonimizacao
        {
            [Display(Name = "Id_status_anonimizacao")]
            public string Id_status_anonimizacao { get; set; }

            [Display(Name = "Nm_status_anonimizacao")]
            public string Nm_status_anonimizacao { get; set; }
        }
    }
}