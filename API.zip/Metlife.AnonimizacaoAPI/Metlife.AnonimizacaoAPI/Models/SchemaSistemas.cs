﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class SchemaSistemas
    {
        public object Id_sistemas { get; set; }
        public object Nm_sistemas { get; set; }

        public SchemaSistemas(object Id_sis, object Nm_sis)
        {
            this.Id_sistemas = Id_sis;
            this.Nm_sistemas = Nm_sis;
        }
    }
}