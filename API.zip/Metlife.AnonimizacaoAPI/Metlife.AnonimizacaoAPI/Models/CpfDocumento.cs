﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class CpfDocumento
    {
        public object Cpf { get; set; }

        public CpfDocumento(object cpf)
        {
            this.Cpf = cpf;
        }
    }
}