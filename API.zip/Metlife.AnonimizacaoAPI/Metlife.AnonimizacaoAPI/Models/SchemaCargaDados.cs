﻿using System;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Metlife.AnonimizacaoAPI.Controllers;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class SchemaCargaDados
    {
        public static void Sistemas()
        {
            Database db = DatabaseFactory.CreateDatabase("ESEG");

            object IdSis = db.ExecuteScalar(CommandType.Text,
            "select Id_sistemas from LGPD.Tb_sistemas");
            object NmSis = db.ExecuteScalar(CommandType.Text,
            "select Nm_sistemas from LGPD.Tb_sistemas");
            SchemasController.sistemas.Add(new SchemaSistemas(IdSis, NmSis));
        }
    }
}