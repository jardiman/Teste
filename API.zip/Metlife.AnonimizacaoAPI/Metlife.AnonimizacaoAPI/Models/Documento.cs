﻿using System;
using System.Collections.Generic;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class Documento
    {

        public List<ListaAnonimizacao> Documentos = new List<ListaAnonimizacao>();
        
        public Documento(List<ListaAnonimizacao> doc)
        {
            this.Documentos = doc;
        }
    }
}