﻿using System;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class Sistemas
    {
        public object Sistema { get; set; }

        public Sistemas(object sis)
        {
            this.Sistema = sis;
        }
    }
}