﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class DadosAnonimizacao
    {
        public string Sistema { get; set; }
        public string Cpf { get; set; }
        public string Status { get; set; }
        public string Observacao { get; set; }
    }

    public class Root
    {
        public List<DadosAnonimizacao> Documentos { get; set; }
    }
}