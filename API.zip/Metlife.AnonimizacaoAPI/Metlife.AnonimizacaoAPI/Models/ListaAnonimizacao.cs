﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class ListaAnonimizacao
    {
        public object Cpf { get; set; }
        public object Sistema { get; set; }

        public ListaAnonimizacao(object sistema, object cpf)
        {
            this.Sistema = sistema;
            this.Cpf = cpf;
        }
    }
}