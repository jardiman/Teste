﻿using System;
using System.Configuration;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Metlife.AnonimizacaoAPI.Controllers;

namespace Metlife.AnonimizacaoAPI.Models
{
    public class CargaAnonimizacao
    {

        public static object Documento { get; set; }
        static object sistema;

        public static void ListaSistemas(object sis)
        {
            ConsultaLgpdController.sistemas.Clear();
            sistema = sis;
            Database db = DatabaseFactory.CreateDatabase("ESEG");

            sis = db.ExecuteScalar(CommandType.Text,
            "select Nm_sistemas from LGPD.Tb_sistemas where Id_sistemas = " + sis);
            ConsultaLgpdController.sistemas.Add(new Sistemas(sis));
        }

        public static void ListaCpfs()
        {
            ConsultaLgpdController.cpfs.Clear();
            Database db = DatabaseFactory.CreateDatabase("ESEG");
            string Limit = ConfigurationManager.AppSettings["Limit.Cpfs"];

            using (IDataReader r = db.ExecuteReader(CommandType.Text, "select top " + Limit + " Nr_cpf from LGPD.Tb_documento_cliente dc JOIN LGPD.Tb_documento_status ds On dc.Id_documento_cliente = ds.Id_documento_cliente	JOIN LGPD.Tb_sistemas s On s.Id_sistemas = ds.Id_sistemas where s.Id_sistemas = " + sistema + " and Dt_anonimizacao is null Order By Nr_cpf"))
            {
                while (r.Read())
                {
                    ConsultaLgpdController.cpfs.Add(new CpfDocumento(r[0].ToString()));
                }
            }
        }

        public static void GravaAnonimizacaoNovo(string Sistema, string Cpf, string Status, string Observacao)
        {
            Database db = DatabaseFactory.CreateDatabase("ESEG");

            Documento = db.ExecuteScalar(CommandType.Text, "Update ds set Nm_status = '" + Status + "', Nm_observacao = '" + Observacao + "', Dt_anonimizacao = Getdate() from LGPD.Tb_documento_cliente dc JOIN LGPD.Tb_documento_status ds On dc.Id_documento_cliente = ds.Id_documento_cliente	JOIN LGPD.Tb_sistemas s On s.Id_sistemas = ds.Id_sistemas where dc.Nr_cpf = '" + Cpf + "' and s.Nm_sistemas = '" + Sistema + "'");
        }
    }
}